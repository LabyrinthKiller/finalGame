# chromaticron
This repo is for the Chromaticron files
For testing, ensure you have python (3.9.x+) and pygame installed (pip install pygame in cmd pannel)
