# Byrne Mansion Update Version Beta 0.9.1 (Library Opening)
* Added code for traversing the bookshelves in the library (the left and right buttons)
* Added the Clock puzzle with functionality
  * Added the Inventory
  * THE LEVER IS SUMMONED AND WORKS PROPERLY
  * Added the key
    * Known Error: The key can be summoned multiple times by completing the clock puzzle multiple times...
    * There was another error that happened on the clock screen where after getting the key and selecting it, I couldn't click the right arrow button as it would just say 'key selected', however this error has mysteriously disappeared...
* File Management (5/18/22)
  * Files are separated through folders in a (hopefully) intuitive way
    * EX: If you need like the clock images for the clock puzzle from the library, use assets/images/Library/puzzle-1/clocks/(insert clock image needed)
    * Hopefully File Management continues.....
* Working on file transfer of the title screen to here...
* Functionality to allow pressing 'e' while in inventory to exit the inventory (5/18/22)